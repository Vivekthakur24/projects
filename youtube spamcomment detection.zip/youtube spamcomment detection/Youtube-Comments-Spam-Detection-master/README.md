# Youtube-Comments-Spam-Detection
A Web Application integrated with Machine Learning to classify YouTube Comments as Spam or Not-Spam

[ Try out my Web App on Heroku !!](https://youtube-spamdetection.herokuapp.com/)
