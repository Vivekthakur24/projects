module.exports = [require('./settingsFind')];
