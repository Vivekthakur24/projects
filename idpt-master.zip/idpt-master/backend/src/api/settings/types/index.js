module.exports = [
  require('./settings'),
  require('./settingsInput'),
];
