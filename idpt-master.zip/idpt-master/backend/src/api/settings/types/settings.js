const schema = `
  type Settings {
    theme: String!
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
