module.exports = [
  require('./patient'),
  require('./patientInput'),
  require('./patientFilterInput'),
  require('./patientOrderByEnum'),
  require('./patientPage'),
  require('./patientEnums'),
];
