module.exports = [
  require('./patientFind'),
  require('./patientList'),
  require('./patientAutocomplete'),
];
