module.exports = [
  require('./patientCreate'),
  require('./patientDestroy'),
  require('./patientUpdate'),
  require('./patientImport'),
];
