module.exports = [
  require('./moduleFind'),
  require('./moduleList'),
  require('./moduleAutocomplete'),
];
