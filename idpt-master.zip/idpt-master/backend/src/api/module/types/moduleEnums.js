const schema = `
  enum ModuleStatusEnum {
    ACTIVE
    INACTIVE
    DRAFT
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
