module.exports = [
  require('./module'),
  require('./moduleInput'),
  require('./moduleFilterInput'),
  require('./moduleOrderByEnum'),
  require('./modulePage'),
  require('./moduleEnums'),
];
