module.exports = [
  require('./videoCreate'),
  require('./videoDestroy'),
  require('./videoUpdate'),
  require('./videoImport')
]
