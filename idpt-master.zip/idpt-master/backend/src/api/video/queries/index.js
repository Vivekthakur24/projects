module.exports = [
  require('./videoFind'),
  require('./videoList'),
  require('./videoAutocomplete')
]
