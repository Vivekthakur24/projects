module.exports = [
  require('./video'),
  require('./videoInput'),
  require('./videoFilterInput'),
  require('./videoOrderByEnum'),
  require('./videoPage'),
  require('./videoEnums')
]
