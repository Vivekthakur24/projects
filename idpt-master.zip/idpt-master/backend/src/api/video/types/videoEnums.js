const schema = `
enum OperatoreEnum {
  GREATERTHAN
  LESSTHAN
  EQUALS
}
`

const resolver = {}

exports.schema = schema
exports.resolver = resolver
