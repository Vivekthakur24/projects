module.exports = [
  require('./audioCreate'),
  require('./audioDestroy'),
  require('./audioUpdate'),
  require('./audioImport'),
];
