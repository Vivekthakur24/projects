module.exports = [
  require('./taskFind'),
  require('./taskList'),
  require('./taskAutocomplete'),
];
