module.exports = [
  require('./taskCreate'),
  require('./taskDestroy'),
  require('./taskUpdate'),
  require('./taskImport'),
];
