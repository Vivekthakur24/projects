module.exports = [
  require('./document'),
  require('./documentInput'),
  require('./evaluationCriteriaInput'),
];
