module.exports = [
  require('./video'),
  require('./videoInput'),
]
