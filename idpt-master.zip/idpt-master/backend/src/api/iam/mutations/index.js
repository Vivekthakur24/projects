module.exports = [
  require('./iamEdit'),
  require('./iamImport'),
  require('./iamCreate'),
  require('./iamRemove'),
  require('./iamChangeStatus'),
];
