module.exports = [
  require('./iamListRoles'),
  require('./iamListUsers'),
  require('./iamFind'),
  require('./iamUserAutocomplete'),
];
