const schema = `
  input IamListRolesFilterInput {
    role: String
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
