module.exports = [
  require('./roleWithUsers'),
  require('./roleWithUsersOrderByEnum'),
  require('./iamListUsersFilterInput'),
  require('./iamListRolesFilterInput'),
  require('./iamCreateInput'),
  require('./iamEditInput'),
  require('./iamImportInput'),
];
