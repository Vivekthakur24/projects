const schema = `
  enum RoleWithUsersOrderByEnum {
    role_ASC
    role_DESC
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
