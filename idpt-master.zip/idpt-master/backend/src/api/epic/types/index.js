module.exports = [
  require('./epic'),
  require('./epicPage'),
  require('./epicOrderByEnum'),
  require('./epicFilterInput'),
  require('./epicCriteriaInput'),
];
