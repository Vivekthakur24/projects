const schema = `
  enum EpicOrderByEnum {
    id_ASC
    createdAt_ASC
    createdAt_DESC
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
