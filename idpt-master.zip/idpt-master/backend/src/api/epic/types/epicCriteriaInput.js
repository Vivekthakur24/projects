exports.schema = `
  input EpicCriteriaInput {
    id: String!
    start: String!
    duration: Int!
  }
`;

exports.resolver = {};
