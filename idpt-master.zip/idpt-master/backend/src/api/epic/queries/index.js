module.exports = [
  require('./find'),
  require('./list'),
  require('./autocomplete'),
];
