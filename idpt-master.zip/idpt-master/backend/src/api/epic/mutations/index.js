module.exports = [
  require('./epicCriteriaUpdate'),
];
