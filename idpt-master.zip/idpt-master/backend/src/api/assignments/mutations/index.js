module.exports = [
  require('./assignmentUpdate'),
  require('./assignmentCreate'),
  require('./assignmentsDestroy'),
];
