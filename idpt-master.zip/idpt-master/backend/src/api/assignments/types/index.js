module.exports = [
  require('./assignment'),
  require('./assignmentEnum'),
  require('./assignmentInput'),
  require('./assignmentFilterInput'),
  require('./assignmentPage'),
  require('./assignmentOrderByEnum'),
];
