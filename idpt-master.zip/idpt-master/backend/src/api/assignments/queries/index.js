module.exports = [
  require('./assignmentsList'),
  require('./assignmentsFind'),
  require('./assignmentsAutocomplete'),
];
