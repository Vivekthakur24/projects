module.exports = [
  require('./authSendPasswordResetEmail'),
  require('./authSendEmailAddressVerificationEmail'),
  require('./authUpdateProfile'),
  require('./authSignUp'),
  require('./authSignIn'),
  require('./authPasswordReset'),
  require('./authVerifyEmail'),
];
