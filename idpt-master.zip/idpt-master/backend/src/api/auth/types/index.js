module.exports = [
  require('./user'),
  require('./userWithRoles'),
  require('./userWithRolesOrderByEnum'),
  require('./userWithRolesPage'),
  require('./userProfileInput'),
];
