module.exports = [
  require('./authIsEmailConfigured'),
  require('./authMe'),
];
