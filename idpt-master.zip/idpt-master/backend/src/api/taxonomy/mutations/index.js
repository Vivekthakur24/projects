module.exports = [
  require('./taxonomyCreate'),
  require('./taxonomyDestroy'),
  require('./taxonomyUpdate'),
  require('./taxonomyImport'),
];
