const schema = `
  enum TaxonomyStatusEnum {
    ACTIVE
    INACTIVE
    DRAFT
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
