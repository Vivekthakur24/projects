module.exports = [
  require('./taxonomy'),
  require('./taxonomyInput'),
  require('./taxonomyFilterInput'),
  require('./taxonomyOrderByEnum'),
  require('./taxonomyPage'),
  require('./taxonomyEnums'),
];
