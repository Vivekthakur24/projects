module.exports = [
  require('./taxonomyFind'),
  require('./taxonomyList'),
  require('./taxonomyAutocomplete'),
];
