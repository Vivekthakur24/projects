const schema = `
  enum RoadmapOrderByEnum {
    id_ASC
    createdAt_ASC
    createdAt_DESC
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
