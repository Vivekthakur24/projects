module.exports = [
  require('./assignmentResponse'),
  require('./assignmentResponsePage'),
  require('./assignmentResponseInput')
]
