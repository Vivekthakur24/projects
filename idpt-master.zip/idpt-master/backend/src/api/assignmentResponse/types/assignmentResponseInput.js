const schema = `
  input assignmentResponseInput {
    assignmentID: String
    formData: JSON
  }
`

const resolver = {}

exports.schema = schema
exports.resolver = resolver
