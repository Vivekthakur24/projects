module.exports = [
  // require('./assignmentResponseUpdate'),
  // require('./assignmentResponseDestroy'),
  require('./assignmentResponseCreate')
]
