module.exports = [ require('./assignmentResponseList') ]
