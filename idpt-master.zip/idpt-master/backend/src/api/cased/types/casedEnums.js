const schema = `
  enum CasedStatusEnum {
    ACTIVE
    INACTIVE
    DRAFT
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
