module.exports = [
  require('./cased'),
  require('./casedInput'),
  require('./casedFilterInput'),
  require('./casedOrderByEnum'),
  require('./casedPage'),
  require('./casedEnums'),
];
