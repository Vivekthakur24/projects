const schema = `
  type AutocompleteOption {
    id: String!
    label: String!
  }
`;

const resolver = {};

exports.schema = schema;
exports.resolver = resolver;
