module.exports = [
  require('./time'),
  require('./dateTime'),
  require('./json'),
  require('./file'),
  require('./fileInput'),
  require('./autocompleteOption'),
];
