module.exports = [require('./auditLogList')];
