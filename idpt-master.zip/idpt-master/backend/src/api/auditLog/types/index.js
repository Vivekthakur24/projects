module.exports = [
  require('./auditLog'),
  require('./auditLogPage'),
  require('./auditLogListFilterInput'),
  require('./auditLogListOrderByEnum'),
];
