module.exports = [
  require('./recordFind'),
  require('./recordList'),
  require('./recordAutocomplete'),
];
