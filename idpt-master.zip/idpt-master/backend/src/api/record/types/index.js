module.exports = [
  require('./record'),
  require('./recordInput'),
  require('./recordFilterInput'),
  require('./recordOrderByEnum'),
  require('./recordPage'),
  require('./recordEnums'),
];
