module.exports = [
  require('./recordCreate'),
  require('./recordDestroy'),
  require('./recordUpdate'),
  require('./recordImport'),
];
