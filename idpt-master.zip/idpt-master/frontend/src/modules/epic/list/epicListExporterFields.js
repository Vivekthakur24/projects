import model from 'modules/epic/epicModel';

const { fields } = model;

export default [
  fields.id,
  fields.url,
  fields.epiclength,
  fields.createdAt,
  fields.updatedAt
];
