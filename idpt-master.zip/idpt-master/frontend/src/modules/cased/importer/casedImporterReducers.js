import importerReducers from 'modules/shared/importer/importerReducers';
import actions from 'modules/cased/importer/casedImporterActions';

export default importerReducers(actions);
