import model from 'modules/audio/audioModel';

const { fields } = model;

export default [
  fields.url,
  fields.audiolength,
];
