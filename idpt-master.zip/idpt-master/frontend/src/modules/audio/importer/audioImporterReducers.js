import importerReducers from 'modules/shared/importer/importerReducers';
import actions from 'modules/audio/importer/audioImporterActions';

export default importerReducers(actions);
