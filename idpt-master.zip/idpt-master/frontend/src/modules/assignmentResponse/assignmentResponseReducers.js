import { combineReducers } from 'redux'
import list from 'modules/assignmentResponse/list/assignmentResponseListReducers'

export default combineReducers({ list })
