import importerReducers from 'modules/shared/importer/importerReducers';
import actions from 'modules/document/importer/documentImporterActions';

export default importerReducers(actions);
