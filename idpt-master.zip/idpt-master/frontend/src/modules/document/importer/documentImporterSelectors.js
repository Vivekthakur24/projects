import importerSelectors from 'modules/shared/importer/importerSelectors';

export default importerSelectors(
  'document.importer',
);
