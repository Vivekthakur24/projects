import model from 'modules/document/documentModel';

const { fields } = model;

export default [
  fields.contentHTML,
  fields.totalreadtime,
];
