import importerReducers from 'modules/shared/importer/importerReducers';
import actions from 'modules/iam/importer/iamImporterActions';

export default importerReducers(actions);
