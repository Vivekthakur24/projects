const backendUrl = `/api`;

export default {
  backendUrl,
};
